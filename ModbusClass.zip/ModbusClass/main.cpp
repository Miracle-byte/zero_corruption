#include <QCoreApplication>
#include <QtDebug>
#include "modbus.h"


void msleep(int msec);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    qDebug() << "--- > Start ModbusClass";

    //har bir E-GATE uchun modbus eksemplyar yaratish
    modbus E_GATE_1("192.168.233.51", 502);
    modbus E_GATE_2("192.168.233.52", 502);
    modbus E_GATE_3("192.168.233.53", 502);
    modbus E_GATE_4("192.168.233.54", 502);
    modbus E_GATE_5("192.168.233.55", 502);
    modbus E_GATE_6("192.168.233.56", 502);

    QThread thread_plc_1;
    QThread thread_plc_2;
    QThread thread_plc_3;
    QThread thread_plc_4;
    QThread thread_plc_5;
    QThread thread_plc_6;

    QObject::connect(&thread_plc_1, &QThread::started, &E_GATE_1, &modbus::run);
    E_GATE_1.moveToThread(&thread_plc_1);
    thread_plc_1.start();

    QObject::connect(&thread_plc_2, &QThread::started, &E_GATE_2, &modbus::run);
    E_GATE_2.moveToThread(&thread_plc_2);
    thread_plc_2.start();

    QObject::connect(&thread_plc_3, &QThread::started, &E_GATE_3, &modbus::run);
    E_GATE_3.moveToThread(&thread_plc_3);
    thread_plc_3.start();

    QObject::connect(&thread_plc_4, &QThread::started, &E_GATE_4, &modbus::run);
    E_GATE_4.moveToThread(&thread_plc_4);
    thread_plc_4.start();

    QObject::connect(&thread_plc_5, &QThread::started, &E_GATE_5, &modbus::run);
    E_GATE_5.moveToThread(&thread_plc_5);
    thread_plc_5.start();

    QObject::connect(&thread_plc_6, &QThread::started, &E_GATE_6, &modbus::run);
    E_GATE_6.moveToThread(&thread_plc_6);
    thread_plc_6.start();

    QString temp_string;
    int counter = 0;
    while(true)
    {
        temp_string = E_GATE_4.readValue;
        qDebug() << temp_string;
        msleep(10);

        counter++;

        if(counter >= 3)
        {
            counter = 0;

            E_GATE_4.writeCommand1 = "led_active";
            msleep(200);
            qDebug() << "writeCommand1 = " << E_GATE_4.readCommand1;
            E_GATE_4.readCommand1 = "";

            E_GATE_4.dtime = 16;
            E_GATE_4.writeCommand2 = "set_D1_timer";
            msleep(200);
            qDebug() << "writeCommand2 = " << E_GATE_4.readCommand2;
            E_GATE_4.readCommand2 = "";

        }
    }

    return a.exec();
}

void msleep(int msec)
{
    QEventLoop loop;
    QTimer::singleShot(msec, &loop, &QEventLoop::quit);
    loop.exec();
}
