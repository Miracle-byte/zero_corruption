#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging

from calendar import monthrange
import mysql.connector
from telegram import (ReplyKeyboardMarkup, ReplyKeyboardRemove)
from telegram.ext import (Updater, CommandHandler, MessageHandler, Filters,
                          ConversationHandler)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)

logger = logging.getLogger(__name__)


TIL,HOLAT,TASHKILOT,YIL,OY,GURUH,START1 = range(7)


def start(update, context):
    reply_keyboard = [['🇺🇿 O`zbekcha','🇷🇺 Русский']]
    update.message.reply_text(
        'Assalamu alaykum.Korrupsiya haqida xabar beruvchi telegram botiga Xush kelibsiz.'
        '\n\nIltimos, Tilni tanlang:\nВыберите язык:\n',
        reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True,one_time_keyboard=True))

    return TIL

def til(update, context):
    reply_keyboard_uz = [['Korrupsiyaga duch keldim va pora berishga majbur bo`ldim'],['Korrupsiyaga duch keldim va pora bermadim'],['Pora bilan bog`liq bo`lmagan korrupsiyaga duch keldim'],['Halol ishlaydigan davlat xizmatchisini uchratdim'],['Orqaga']]
    user = update.message.from_user
    text1 = update.message.text 
    logger.info("%sning tanlagan tili: %s", user.first_name, update.message.text)
    if text1 == '🇺🇿 O`zbekcha':
        update.message.reply_text(
            'Siz korrupsiya bo`yicha qanday holatga duch keldingiz?',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard_uz,resize_keyboard=True, one_time_keyboard=True))

    return HOLAT

#HOLAT
def holat(update, context):
    reply_keyboard = [['Vazirliklar','Mahalliy davlat hokimiyati organlari'],['Banklar','Davlat qo`mitalari'],['Orqaga']]
    if update.message.text == 'Orqaga':
        reply_keyboard = [['🇺🇿 O`zbekcha','🇷🇺 Русский']]
        update.message.reply_text(
            'Iltimos, Tilni tanlang:\nВыберите язык:\n',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True,one_time_keyboard=True))
        return TIL
    user = update.message.from_user
    logger.info("%sning tanlov turi: %s", user.first_name, update.message.text)
    
    update.message.reply_text(
        'Bo`limni tanlang:',reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True,one_time_keyboard=True))
    return TASHKILOT


#TASHKILOT
def tashkilot(update, context):
    reply_keyboard = []
    if update.message.text == 'Orqaga':
        reply_keyboard = [['Vazirliklar','Mahalliy davlat hokimiyati organlari'],['Banklar','Davlat qo`mitalari'],['Orqaga']]
        update.message.reply_text(
            'Bo`limni tanlang:',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))
        return TIL
    if update.message.text == 'Vazirliklar':
        file1 = open('list.txt', 'r',encoding="utf8")
        Lines = file1.readlines()
        for line in Lines:
            test1 = []
            test1.append(line.strip())
            reply_keyboard.append(test1)
        update.message.reply_text(
            'Tashkilotni tanlang:',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))  

    if update.message.text == 'Mahalliy davlat hokimiyati organlari':
        file1 = open('list1.txt', 'r',encoding="utf8")
        Lines = file1.readlines()
        for line in Lines:
            test1 = []
            test1.append(line.strip())
            reply_keyboard.append(test1)
        update.message.reply_text(
            'Tashkilotni tanlang:',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))    
    
    if update.message.text == 'Banklar':
        file1 = open('list2.txt', 'r',encoding="utf8")
        Lines = file1.readlines()
        for line in Lines:
            test1 = []
            test1.append(line.strip())
            reply_keyboard.append(test1)
        update.message.reply_text(
            'Tashkilotni tanlang:',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))
    
    if update.message.text == 'Davlat qo`mitalari':
        file1 = open('list3.txt', 'r',encoding="utf8")
        Lines = file1.readlines()
        for line in Lines:
            test1 = []
            test1.append(line.strip())
            reply_keyboard.append(test1)
        update.message.reply_text(
            'Tashkilotni tanlang:',
            reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))


#yil
def yil(update, context):
    if update.message.text == 'Orqaga':
        reply_keyboard = [['Orqaga']]
        update.message.reply_text(
        'Id ni kiriting',reply_markup=ReplyKeyboardMarkup
        (reply_keyboard,resize_keyboard=True,one_time_keyboard=True))
        return TANLOV
    context.user_data['yil'] = update.message.text
    reply_keyboard = [['Yanvar','Fevral','Mart'],['Aprel','May','Iyun'],['Iyul','Avgust','Sentabr'],['Oktabr','Noyabr','Dekabr'],['Orqaga']]
    user = update.message.from_user
    logger.info("%sning tanlov turi(Yil): %s", user.first_name, update.message.text)
    
    update.message.reply_text(
        'Iltimos, oyni tanlang',
        reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))

    return OY

#oy
def oy(update, context):
    if update.message.text == 'Orqaga':
        reply_keyboard = [['2019'],['2020'],['Orqaga']]
        update.message.reply_text(
                'Iltimos, yilni tanlang',
                reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))
        return YIL

    reply_keyboard = [['Yanvar','Fevral','Mart'],['Aprel','May','Iyun'],['Iyul','Avgust','Sentabr'],['Oktabr','Noyabr','Dekabr'],['Orqaga']] 
    user = update.message.from_user
    logger.info("%sning tanlov turi: %s", user.first_name, update.message.text)
    select_oy = update.message.text
    oy1 = str(get_oy_number(select_oy))
    print(context.user_data['yil'],context.user_data['abty_id'])
    davomat = print_database_data(context.user_data['abty_id'],context.user_data['yil'],oy1)
    update.message.reply_text(
    str(davomat),
        reply_markup=ReplyKeyboardMarkup(reply_keyboard,resize_keyboard=True, one_time_keyboard=True))
    return OY

#Bazadagi davomatni o`qish
def print_database_data(id_abitur,yil,oy):
    davomat_message = ""
    mydb = mysql.connector.connect(host="localhost",user="root",passwd="",database="nekov")
    mycursor = mydb.cursor()

    hisob_oy = number_of_days_in_month(int(yil), int(oy))
    logger.info("hisob oy:%d",hisob_oy)
    for x in range(hisob_oy):
        x+=1
        if x<10:
            x = "0"+str(x)
        else:
            x = str(x)    
        tq1 = ""
        tq2 = ""
        tt1 = 0
        tt2 = 0
        davomat_message += str(x)+"."+str(oy)+"."+str(yil)
        vaqt = str(yil)+"-"+str(oy)+"-"+str(x)+"%"
        logger.info("%s",vaqt)
        mycursor.execute("SELECT * FROM davomat_finger WHERE abty_id = %s and time like %s",(int(id_abitur),vaqt,))
        myresult = mycursor.fetchall()

        for row in myresult:
            if mycursor.rowcount == 1:
                tq1 += "-keldi:"+str(row[3].strftime("%H:%M"))+"; ketdi:--:--"
            else:
                if row[2] == 1:
                    tq1 += "; ketdi:"+str(row[3].strftime("%H:%M"))
                    tt1 = tt1+1
                if row[2] == 0:
                    tq2 = "-keldi:"+str(row[3].strftime("%H:%M"))
                    tt2 = tt2+1
        if tt1 != tt2:
            davomat_message += tq2+"; ketdi:--:--"+ "\n"
        else:
            davomat_message += tq2 + tq1+ "\n"
    logger.info("%s",davomat_message)
    return davomat_message



#abituriyent idsini tekshirish
def check_abty_id(id2):
    mydb = mysql.connector.connect(host="localhost",user="root",passwd="",database="nekov")
    mycursor = mydb.cursor()
    mycursor.execute("SELECT id FROM abty WHERE id = %s",(int(id2),))
    mycursor.fetchall()
    if mycursor.rowcount > 0:
        return True
    else:
        return False

#oyni raqamini olish
def get_oy_number(oy):

    if oy == "Yanvar":
        return '01'
    elif oy == "Fevral":
        return '02'
    elif oy == "Mart":
        return '03'
    elif oy == "Aprel":
        return '04'
    elif oy == "May":
        return '05'
    elif oy == "Iyun":
        return '06'
    elif oy == "Iyul":
        return '07'
    elif oy == "Avgust":
        return '08'
    elif oy == "Sentabr":
        return '09'
    elif oy == "Oktabr":
        return '10'
    elif oy == "Noyabr":
        return '11'
    elif oy == "Dekabr":
        return '12'


#oydagi kunlar soni
def number_of_days_in_month(year, month):
    return monthrange(year, month)[1]


def cancel(update, context):
    user = update.message.from_user
    logger.info("User %s canceled the conversation.", user.first_name)
    update.message.reply_text('Telegram botimizda ko`rishguncha, Xayr!',
                              reply_markup=ReplyKeyboardRemove())

    return ConversationHandler.END


def error(update, context):
    """Log Errors caused by Updates."""
    logger.warning('Update "%s" caused error "%s"', update, context.error)


def main():
    # Create the Updater and pass it your bot's token.
    # Make sure to set use_context=True to use the new context based callbacks
    # Post version 12 this will no longer be necessary
    updater = Updater("5066747231:AAHixapdIV_8qjtt52drb-9_OKfLpQ_135Y", use_context=True)

    # Get the dispatcher to register handlers
    dp = updater.dispatcher

    # Add conversation handler with the states GENDER, PHOTO, LOCATION and BIO
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],

        states={
            TIL: [MessageHandler(Filters.regex('^(🇺🇿 O`zbekcha|🇷🇺 Русский)$'), til)],
            HOLAT: [MessageHandler(Filters.regex('^(Korrupsiyaga duch keldim va pora berishga majbur bo`ldim|Korrupsiyaga duch keldim va pora bermadim|Pora bilan bog`liq bo`lmagan korrupsiyaga duch keldim|Halol ishlaydigan davlat xizmatchisini uchratdim|Orqaga)$'), holat)],
            TASHKILOT: [MessageHandler(Filters.regex('^(Vazirliklar|Mahalliy davlat hokimiyati organlari|Banklar|Davlat qo`mitalari|Orqaga)$'), tashkilot)], 
            YIL: [MessageHandler(Filters.regex('^(2019|2020|Orqaga)$'), yil)],
            OY: [MessageHandler(Filters.regex('^(Yanvar|Fevral|Mart|Aprel|May|Iyun|Iyul|Avgust|Sentabr|Oktabr|Noyabr|Dekabr|Orqaga)$'), oy)]
        },

        fallbacks=[CommandHandler('cancel', cancel)]
    )

    dp.add_handler(conv_handler)

    # log all errors
    dp.add_error_handler(error)

    # Start the Bot
    updater.start_polling()

    # Run the bot until you press Ctrl-C or the process receives SIGINT,
    # SIGTERM or SIGABRT. This should be used most of the time, since
    # start_polling() is non-blocking and will stop the bot gracefully.
    updater.idle()


if __name__ == '__main__':
    main()